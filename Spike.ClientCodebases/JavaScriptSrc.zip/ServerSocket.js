function ServerSocket(channel){

	/* ServerChannel */
	this.channel = channel;

	/* Server EndPoint url */
	this.endPoint = channel.endPoint;

	/* Reception buffer */
	this.buffer = new ByteArray([]);

	/* Partial record flag */
	this.partialRecord = false;

	/* 'Socket' object to use for all communication*/
	this.socket = io.connect(this.endPoint);
	this.socket.serverSocket = this;
	this.socket.socket.serverSocket = this;

	/* Socket transport currently used */
	this.transport = "";

	/* Connect event function */
	this.channel.onConnect = function(eventHandler){ 
		var toCall = eventHandler;
		this.socket.socket.on('connect', function(){  
			this.serverSocket.transport = this.socket.transport.name;
			toCall(); 
		});
	};

	/* Disconnect event function */
	this.channel.onDisconnect = function(eventHandler){ 
		var toCall = eventHandler;
		this.socket.socket.on('disconnect', function(){  
			toCall(); 
		});
	};

	/* Sends the data to the remote endpoint */
	this.send = function(operationKey, packet) {
		// Initialize size variables
		var sizeOfKey = 4;
		var sizeOfLen = 4;
		var sizeTotal = 8;

		// Writes the length of the packet, the operation and the data
		var length   = packet == null ? 0 : packet.buffer.data.length;
		var compiled = new PacketWriter();

		// Write the length of the packet
		compiled.writeUInt32(length + sizeOfKey);

		// Write the key of the packet
		compiled.writeKey(operationKey);
	
		// Write the body
		if(length > 0){
			compiled.buffer.writeBytes(packet.buffer.data);
		}

		// Send the payload in base64
		this.socket.send( compiled.buffer.toBase64() );
	};

	/* Invoked when the socked receives incoming data */
	this.socket.on('message', function(payload) {
		// Initialize size variables
		var sizeOfKey = 4;
		var sizeOfLen = 4;
		var sizeTotal = 8;

		var data = new ByteArray([]);
		var socket = this.serverSocket;
		if(socket.partialRecord)
		{
			socket.buffer.readBytesTo(data, socket.buffer.getSize());
			socket.partialRecord = false;
		}			

		// Read received data
		data.writeBase64(payload);

		// While we have data to read
		while(data.position < data.getSize())
		{
			if(data.getSize() - data.position < sizeOfLen)
			{
				// Read the partial packet 
				socket.buffer = new ByteArray([]);
				data.readBytesTo(socket.buffer, data.getSize() - data.position);
				socket.partialRecord = true;
				break;
			} 
			
			var Length = data.readInt(32, false) + sizeOfLen;
			data.position -= sizeOfLen;
			
		    // If we have enough data to form a full packet.
		    if(Length <= (data.getSize() - data.position))
		    {
				// Read the operation and read the actual message into a new buffer
				var messageLength = data.readInt(32, false); // UNUSED
				var operation = "";
				for (var i=0; i < sizeOfKey; i++)
				{
					var byte = data.readInt(8, false);
					var sbyte = byte.toString(16);
					if(sbyte.length == 1)
						sbyte = "0" + sbyte;
					operation += sbyte;
				}
				operation = operation.toUpperCase();

				// New buffer for the packet
				var packet = new ByteArray([]);
				data.readBytesTo(packet, Length - sizeTotal);
				packet.position = 0;
		
				// Create the reader and fire the event
				if(socket.channel != 'undefined' && socket.channel != null && socket.channel.onReceive != 'undefined' && socket.channel.onReceive != null)
				{
					var reader = new PacketReader(packet);
					socket.channel.onReceive(operation, reader);
				}
		    }
		    else 
		    {
		     	// Read the partial packet
				socket.buffer = new ByteArray([]);
				data.readBytesTo(socket.buffer, data.getSize() - data.position);
				socket.partialRecord = true;
		    }
		
		}

	});


}