package com.misakai.spike.network;

@FunctionalInterface
public interface PacketHandler<Packet> {
	void onReceive(Packet packet);
}
