package com.misakai.spike.network;

/**
 * The listener interface for receiving connection events. The class must define a method of no arguments called onConnect. 
 */
@FunctionalInterface
public interface ConnectionHandler {
	/**
	 * Invoked when a connection occurs.
	 */
	public void onConnect();
}
