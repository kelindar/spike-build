﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Spike.Network
{
    /// <summary>
    /// Represents a TCP/IP network channel.
    /// </summary>
    public abstract class TcpChannelBase : ChannelBase, IDisposable
    {
        private TcpSocket fSocket;
        private RayHttpEncoder fRay;
        private bool fUseRayTunneling = false;

        /// <summary>
        /// Constructs a TCP/IP network channel.
        /// </summary>
        public TcpChannelBase() : base("tcp")
        {
            fSocket = new TcpSocket(this);
            fRay = new RayHttpEncoder();
        }

        /// <summary>
        /// Connects to the server
        /// </summary>
        protected override void Connect()
        {
            if (this.IsConnected)
                throw new InvalidOperationException("Unable to connect as the socket is currently connected. Please disconnect first.");

            // Create a new socket
            fSocket = new TcpSocket(this);

            // Attempt to connect.
            fSocket.Connect(fEndPoint);

            // Setup ray tunneling if necessary.
            if (this.UseRayTunneling)
                IssueRayConnect();

            // If no exception was thrown, we should issue the connect event
            this.OnConnected();
        }

        /// <summary>
        /// Disconnects from the server
        /// </summary>
        public override void Disconnect()
        {
            if (this.IsConnected)
            {
                try
                {
                    // Attempt to disconnect.
                    fSocket.Disconnect(true);
                }
                finally
                {
                    // Always send the disconnected event after the call
                    this.OnDisconnected();
                }
            }
        }

        /// <summary>
        /// Invokes an operation on the server
        /// </summary>
        /// <param name="operationKey">The identifier for the operation to invoke on the server</param>
        /// <param name="packet">The body packet, can be null depending on the protocol specification</param>
        public override void Send(string operationKey, IPacket packet)
        {
            try
            {
                // Forward
                PacketWriter writer = new PacketWriter();
                if (packet != null)
                    writer.Write(packet);
                fSocket.Send(operationKey, writer);
            }
            catch (Exception ex)
            {
                // Check for disconnected state
                if (!this.IsConnected)
                    this.OnDisconnected();

                // Rethrow
                throw ex;
            }
        }

        /// <summary>
        /// Gets/Sets whether the send aggregation should be used
        /// One must explicitly call SendAllPending() to send data in aggregated mode
        /// </summary>
        public override bool UseCoalescing
        {
            get { return fSocket.UseCoalescing; }
            set { fSocket.UseCoalescing = value; }
        }

        /// <summary>
        /// Gets/Sets whether this tcp connection should be tunneled through Spike Ray.
        /// </summary>
        public bool UseRayTunneling
        {
            get { return fUseRayTunneling; }
            set 
            {
                if (fUseRayTunneling == value)
                    return;

                fUseRayTunneling = value;
                this.PacketEncoder = value ? fRay : null;
                if(value && this.IsConnected)
                    IssueRayConnect();
            }
        }

        /// <summary>
        /// Gets a value that indicates whether the channel is connected
        /// to a remote host as of the last send/receive operation.
        /// </summary>
        public override bool IsConnected
        {
            get { return fSocket == null ? false : fSocket.Connected && fSocket.IsConnected; }
        }

        /// <summary>
        /// If the channel is in aggregated mode, this will send all pending packets to the server
        /// </summary>
        public override void SendAllPending()
        {
            try
            {
                // Forward
                if (fSocket.UseCoalescing && fSocket.Connected)
                    fSocket.SendAllPending();
            }
            catch (Exception ex)
            {
                // Check for disconnected state
                if (!this.IsConnected)
                    this.OnDisconnected();

                // Rethrow
                throw ex;
            }
        }

        /// <summary>
        /// Performs a socket receive, will dispatch the events (all in the same thread)
        /// </summary>
        public override void Receive()
        {
            try
            {
                // Forward
                fSocket.Receive();
            }
            catch (Exception ex)
            {
                // Rethrow
                throw ex;
            }
            finally
            {
                // Check for disconnected state
                if (!this.IsConnected)
                    this.OnDisconnected();
            }
        }

        #region IDisposable Members

        public void Dispose()
        {
            try
            {
                if (fSocket != null && fSocket.Connected)
                    fSocket.Disconnect(false);
            }
            catch (Exception)
            {
                // We can not throw in dispose.
            }
        }

        #endregion

        #region Ray Members

        /// <summary>
        /// Issues Spike Ray HTTP CONNECT in order to establish an http tunnel.
        /// </summary>
        private void IssueRayConnect()
        {
            if (!this.IsConnected)
                return;

            StringBuilder packet = new StringBuilder();
            packet.Append("CONNECT http://");
            packet.Append(fEndPoint.ToString());
            packet.Append(" HTTP/1.1");
            packet.Append("\r\nHost: ");
            packet.Append(fEndPoint.ToString());
            packet.Append("\r\nConnection: keep-alive");
            packet.Append("\r\nProxy-Connection: keep-alive");
            packet.Append("\r\nRay-Type: 1.0");
            packet.Append("\r\nContent-Length: 0");
            packet.Append("\r\n\r\n");

            try
            {
                // Send it through the socket now
                fSocket.Send(Encoding.ASCII.GetBytes(packet.ToString()));
            }
            catch (Exception ex)
            {
                // Check for disconnected state
                if (!this.IsConnected)
                    this.OnDisconnected();

                // Rethrow
                throw ex;
            }
        }

        #endregion
    }
}
