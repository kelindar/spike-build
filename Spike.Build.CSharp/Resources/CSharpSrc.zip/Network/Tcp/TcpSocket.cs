﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace Spike.Network
{
    internal sealed class TcpSocket : Socket
    {
        private TcpChannelBase fChannel;
        private PacketReader fReader = new PacketReader(1024);
        private MemoryStream fCoalesceStream = null;
        private byte[] fBuffer = new byte[0];
        private bool fPartialRecord = false;
        internal bool UseCoalescing;

        internal TcpSocket(TcpChannelBase channel)
            : base(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
        {
            fChannel = channel;
        }

        internal void Send(string operationKey, PacketWriter writer)
        {
            try
            {
                // Writes the length of the packet, the operation and the data
                int streamLength = (int)writer.Length + Packet.HeaderSize;
                using (MemoryStream stream = new MemoryStream(streamLength))
                {
                    // Write the operation number
                    int length = (int)writer.Length + Packet.HeaderKeySize;
                    ChannelBase.WriteLength(stream, length);

                    // Write the operation number
                    ChannelBase.WriteKey(stream, operationKey);

                    // Write the packet data
                    if (writer.Length > 0)
                        stream.Write(writer.UnderlyingStream.GetBuffer(), 0, (int)writer.Length);

                    // Send to the server
                    if (UseCoalescing)
                    {
                        if (fCoalesceStream == null) fCoalesceStream = new MemoryStream();
                        int packetLength = (int)stream.Length;
                        fCoalesceStream.SetLength(fCoalesceStream.Length + packetLength);
                        fCoalesceStream.Write(stream.GetBuffer(), 0, packetLength);
                    }
                    else // Send to the server now
                    {
                        byte[] packet = stream.GetBuffer();
                        if (fChannel.PacketEncoder != null)
                            fChannel.PacketEncoder.EncodeOutgoingPacket(fChannel, ref packet, ref streamLength);
                        Send(packet, streamLength, SocketFlags.None);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Sends pending data (if aggregated is active)
        /// </summary>
        internal void SendAllPending()
        {
            if (fCoalesceStream != null && fCoalesceStream.Length > 0)
            {
                Send(fCoalesceStream.GetBuffer(), (int)fCoalesceStream.Length, SocketFlags.None);
                fCoalesceStream.SetLength(0);
                fCoalesceStream.Position = 0;
            }
        }

        /// <summary>
        /// Performs a check if it can receive the data then receives, reads packets & dispatches the envents
        /// </summary>
        internal void Receive()
        {
            int availableBytes = Available;
            if (availableBytes == 0)
                return;

            byte[] received = new byte[availableBytes];
            int readBytes = Receive(received, availableBytes, SocketFlags.None);

            if (fChannel.PacketEncoder != null)
                fChannel.PacketEncoder.DecodeIncomingPacket(fChannel, ref received, ref readBytes);

            int bufferSize = readBytes + fBuffer.Length;
            using (MemoryStream data = new MemoryStream(bufferSize))
            {
                if (fPartialRecord)
                {
                    data.Write(fBuffer, 0, fBuffer.Length);
                    fPartialRecord = false;
                }

                data.Write(received, 0, readBytes);
                data.Position = 0;

                // While we have data to read
                while (data.Position < data.Length)
                {
                    if (data.Length - data.Position < Packet.HeaderLengthSize)
                    {
                        // Bad situation, we don't even have the full packet here.
                        // Read the partial packet (few bytes)
                        fBuffer = new byte[data.Length - data.Position];
                        data.Read(fBuffer, 0, fBuffer.Length);
                        fPartialRecord = true;
                        break;
                    }

                    int Length = ChannelBase.ReadLength(data) + Packet.HeaderLengthSize;
                    data.Position -= Packet.HeaderLengthSize;

                    // If we have enough data to form a full packet.
                    if (Length <= (data.Length - data.Position))
                    {
                        // Read the operation and read the actual message into a new buffer
                        int messageLength = ChannelBase.ReadLength(data); // UNUSED
                        string operation  = ChannelBase.ReadKey(data);

                        // Reset the reader and read the bytes from the socket into its buffer
                        byte[] readBuffer = fReader.Reset(Length - Packet.HeaderSize);
                        data.Read(readBuffer, 0, Length - Packet.HeaderSize);

                        // Dispatch the event
                        object fullPacket = OperationReaderBase.Instance.Read(operation, fReader);
                        fReader.Release();
                        fChannel.OnReceive(new ChannelReceiveEventArgs(operation, fullPacket));
                    }
                    else
                    {
                        // Read the partial packet
                        fBuffer = new byte[data.Length - data.Position];
                        data.Read(fBuffer, 0, fBuffer.Length);
                        fPartialRecord = true;
                    }
                }
            }
        }

        /// <summary>
        /// Checks whether the current <see cref="TcpSocket"/> is connected or not.
        /// </summary>
        public bool IsConnected
        {
            get
            {
                try
                {
                    bool part1 = this.Poll(1000, SelectMode.SelectRead);
                    bool part2 = this.Available == 0;
                    if (part1 & part2)
                        return false;
                    return true;
                }
                catch(Exception)
                {
                    return false;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (fCoalesceStream != null)
                fCoalesceStream.Dispose();
        }

    }
}
