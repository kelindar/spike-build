﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Spike.Network
{
    internal static class SupportedTypes
    {
        internal static Dictionary<Type, int> Map;
        static SupportedTypes()
        {
            Map = new Dictionary<Type, int>();
            Map.Add(typeof(Byte),0);
            Map.Add(typeof(Int16),1);
            Map.Add(typeof(Int32),2);
            Map.Add(typeof(Int64),3);
            Map.Add(typeof(UInt16),4);
            Map.Add(typeof(UInt32),5);
            Map.Add(typeof(UInt64),6);
            Map.Add(typeof(Boolean),7);
            Map.Add(typeof(Single),8);
            Map.Add(typeof(Double),9);
            Map.Add(typeof(DateTime),10);
            Map.Add(typeof(String),11);
        }
    }
}
