﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Spike.Network
{
    /// <summary>
    /// Represents a packet encoder that encodes/decodes packets accordingly to the Ray format.
    /// </summary>
    public class RayHttpEncoder : IPacketEncoder
    {
        /// <summary>
        /// Defines how the outgoing packet is encoded. This may modify packet.CompiledBuffer property in order
        /// to recompile the packet body.
        /// </summary>
        /// <param name="channel">The channel that sends the packet.</param>
        /// <param name="buffer">The data buffer to send.</param>
        /// <param name="length">The length of the data buffer to send.</param>
        public virtual void EncodeOutgoingPacket(ChannelBase channel, ref byte[] buffer, ref int length)
        {
            // Encode the body to Base64 String
            string utf8Payload = System.Convert.ToBase64String(buffer, 0, length);
            byte[] contentBuffer = Encoding.UTF8.GetBytes(utf8Payload);

            // Prepare HTTP Headers
            string endPoint = channel.EndPoint.ToString();
            StringBuilder headers = new StringBuilder();
            headers.Append("POST http://");
            headers.Append(endPoint);
            headers.Append(" HTTP/1.1");
            headers.Append("\r\nHost: ");
            headers.Append(endPoint);
            headers.Append("\r\nRay-Type: 1.0");
            headers.Append("\r\nContent-Length: ");
            headers.Append(contentBuffer.Length);
            headers.Append("\r\n\r\n");
            byte[] headersBuffer = Encoding.ASCII.GetBytes(headers.ToString());

            // Compile final buffer
            byte[] compiled = new byte[headersBuffer.Length + contentBuffer.Length];
            Buffer.BlockCopy(headersBuffer, 0, compiled, 0, headersBuffer.Length);
            Buffer.BlockCopy(contentBuffer, 0, compiled, headersBuffer.Length, contentBuffer.Length);

            // Return
            buffer = compiled;
            length = compiled.Length;
        }

        /// <summary>
        /// Defines how the incoming packet is decoded.
        /// </summary>
        /// <param name="channel">The channel that received the packet.</param>
        /// <param name="buffer">The received data buffer.</param>
        /// <param name="length">The length of the received data buffer.</param>
        public virtual void DecodeIncomingPacket(ChannelBase channel, ref byte[] buffer, ref int length)
        {
            // Skip the header until CRLF CRLF and decode the body
            using (MemoryStream stream = new MemoryStream())
            {
                int start = 0;
                int end = length;
                int idx = 0;
                int len = Math.Min(length, buffer.Length);
                while (idx < len - 4)
                {
                    if (buffer[idx] == 0x0D &&
                        buffer[idx + 1] == 0x0A &&
                        buffer[idx + 2] == 0x0D &&
                        buffer[idx + 3] == 0x0A)
                    {
                        start = idx + 4;
                    }

                    if (start > 0 &&
                        buffer[idx] == '/' &&
                        buffer[idx + 1] == '1' &&
                        buffer[idx + 2] == '.' &&
                        buffer[idx + 3] == '1')
                    {
                        // HTTP/1.1
                        end = idx - 4;

                        // Get Payload
                        string utf8Payload = Encoding.UTF8.GetString(buffer, start, end - start);
                        byte[] decoded = System.Convert.FromBase64String(utf8Payload);
                        stream.Write(decoded, 0, decoded.Length);

                        start = 0;
                        end = length;
                    }

                    idx++;
                }

                // Get Payload
                if (start > 0)
                {
                    string utf8PayloadLast = Encoding.UTF8.GetString(buffer, start, end - start);
                    byte[] decodedLast = System.Convert.FromBase64String(utf8PayloadLast);
                    stream.Write(decodedLast, 0, decodedLast.Length);
                }

                // Get the resut buffer
                buffer = stream.GetBuffer();
                length = (int)stream.Length;
            }
        }

    }
}
