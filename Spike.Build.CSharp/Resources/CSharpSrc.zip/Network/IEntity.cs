﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Spike.Network
{
    public interface IEntity
    {
        void Read(PacketReader reader);
        void Write(PacketWriter writer);
    }

}
