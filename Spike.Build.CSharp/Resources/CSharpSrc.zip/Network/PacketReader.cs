using System;
using System.Text;
using System.IO;
using System.Collections.Generic;

namespace Spike.Network
{
    public class PacketReader
    {
        #region Ctor & Properties
        // Static encoding (perf tweak)
        private static Encoding UTF8 = Encoding.UTF8;
        private static BufferPool Buffers = new BufferPool(2, 4 * 1024 * 1024);

        // Binary data
        private byte[] Data;
        private int Size;
        private int Index;
        private int BufferHandle = -1;

        public PacketReader(int size)
        {
            if (BufferHandle > 0)
                Buffers.Release(BufferHandle);
            BufferHandle = Buffers.Acquire(out Data, size);
            Size = size;
            Index = 0;
        }

        public byte[] Reset(int size)
        {
            if (BufferHandle > 0)
                Buffers.Release(BufferHandle);
            BufferHandle = Buffers.Acquire(out Data, size);
            Size = size;
            Index = 0;
            return Data;
        }

        public void Release()
        {
            if (BufferHandle > 0)
                Buffers.Release(BufferHandle);
            BufferHandle = -1;
            Size = 0;
            Index = 0;
        }

        #endregion

        #region Reading Methods

        public int Seek(int offset, SeekOrigin origin)
        {
            switch (origin)
            {
                case SeekOrigin.Begin: Index = offset; break;
                case SeekOrigin.Current: Index += offset; break;
                case SeekOrigin.End: Index = Size - offset; break;
            }

            return Index;
        }

        public long ReadInt64()
        {
            if ((Index + 8) > Size)
                return 0;

            long value = Data[Index++];
            value <<= 8;
            value |= Data[Index++];
            value <<= 8;
            value |= Data[Index++];
            value <<= 8;
            value |= Data[Index++];
            value <<= 8;
            value |= Data[Index++];
            value <<= 8;
            value |= Data[Index++];
            value <<= 8;
            value |= Data[Index++];
            value <<= 8;
            value |= Data[Index++];

            return value;
        }


        public ulong ReadUInt64()
        {
            if ((Index + 8) > Size)
                return 0;

            ulong value = Data[Index++];
            value <<= 8;
            value |= Data[Index++];
            value <<= 8;
            value |= Data[Index++];
            value <<= 8;
            value |= Data[Index++];
            value <<= 8;
            value |= Data[Index++];
            value <<= 8;
            value |= Data[Index++];
            value <<= 8;
            value |= Data[Index++];
            value <<= 8;
            value |= Data[Index++];

            return value;
        }


        public int ReadInt32()
        {
            if ((Index + 4) > Size)
                return 0;

            return Data[Index++] << 24
                 | (Data[Index++] << 16)
                 | (Data[Index++] << 8)
                 | (Data[Index++]);

        }

        public short ReadInt16()
        {
            if ((Index + 2) > Size)
                return 0;

            return (short)((Data[Index++] << 8) | Data[Index++]);
        }

        public byte ReadByte()
        {
            if ((Index + 1) > Size)
                return 0;

            return Data[Index++];
        }

        public uint ReadUInt32()
        {
            if ((Index + 4) > Size)
                return 0;

            return (uint)((Data[Index++] << 24) | (Data[Index++] << 16) | (Data[Index++] << 8) | Data[Index++]);
        }

        public ushort ReadUInt16()
        {
            if ((Index + 2) > Size)
                return 0;

            return (ushort)((Data[Index++] << 8) | Data[Index++]);
        }

        public sbyte ReadSByte()
        {
            if ((Index + 1) > Size)
                return 0;

            return (sbyte)Data[Index++];
        }

        public bool ReadBoolean()
        {
            if ((Index + 1) > Size)
                return false;

            return (Data[Index++] != 0);
        }

        public string ReadString()
        {
            int length = ReadInt32();
            if (length == 0)
                return String.Empty;
            string result = UTF8.GetString(Data, Index, length);
            Index += length;
            return result;
        }

        public DateTime ReadDateTime()
        {
            short year = ReadInt16();
            short month = ReadInt16();
            short day = ReadInt16();
            short hour = ReadInt16();
            short minute = ReadInt16();
            short second = ReadInt16();
            short millisecond = ReadInt16();

            return new DateTime(year, month, day, hour, minute, second, millisecond);
            //return new DateTime(long.Parse(ReadString()));
        }


        /// <summary>
        /// Reads an IEEE 754 double-precision (64-bit) floating-point number from the buffer
        /// </summary>
        public double ReadDouble()
        {
            return BitConverter.Int64BitsToDouble(ReadInt64());
        }

        /// <summary>
        /// Reads an IEEE 754 single-precision (32-bit) floating-point number from the buffer
        /// </summary>
        public float ReadSingle()
        {
            return BitConverter.ToSingle(Data, Index);
        }


        /// <summary>
        /// Reads a list of packets
        /// </summary>
        public void ReadEntity(IEntity entity)
        {
            entity.Read(this);
        }

        /// <summary>
        /// Reads a byte array 
        /// </summary>
        public byte[] ReadByteArray()
        {
            int length = ReadInt32();
            byte[] result = new byte[length];
            Buffer.BlockCopy(Data, Index, result, 0, length);
            Index += length;
            return result;
        }

        /// <summary>
        /// Reads a dynamic value (of the supported types)
        /// </summary>
        public Object ReadDynamic()
        {
            if (ReadByte() == 1)
            {
                string stringType = "System." + ReadString();
                Type type = Type.GetType(stringType);
                switch (SupportedTypes.Map[type])
                {
                    case 0: return ReadByte();
                    case 1: return ReadInt16();
                    case 2: return ReadInt32();
                    case 3: return ReadInt64();
                    case 4: return ReadUInt16();
                    case 5: return ReadUInt32();
                    case 6: return ReadUInt64();
                    case 7: return ReadBoolean();
                    case 8: return ReadSingle();
                    case 9: return ReadDouble();
                    case 10: return ReadDateTime();
                    case 11: return ReadString();
                    default: return null;
                }
            }
            return null;
        }


        /// <summary>
        /// Reads a list 
        /// </summary>
        public List<bool> ReadListOfBoolean()
        {
            int length = ReadInt32();
            List<bool> result = new List<bool>();
            for (int i = 0; i < length; ++i)
                result.Add((bool)ReadBoolean());
            return result;
        }

        /// <summary>
        /// Reads a list 
        /// </summary>
        public List<byte> ReadListOfByte()
        {
            int length = ReadInt32();
            List<byte> result = new List<byte>();
            for (int i = 0; i < length; ++i)
                result.Add(ReadByte());
            return result;
        }

        /// <summary>
        /// Reads a list 
        /// </summary>
        public List<sbyte> ReadListOfSByte()
        {
            int length = ReadInt32();
            List<sbyte> result = new List<sbyte>();
            for (int i = 0; i < length; ++i)
                result.Add(ReadSByte());
            return result;
        }

        /// <summary>
        /// Reads a list 
        /// </summary>
        public List<short> ReadListOfInt16()
        {
            int length = ReadInt32();
            List<short> result = new List<short>();
            for (int i = 0; i < length; ++i)
                result.Add(ReadInt16());
            return result;
        }

        /// <summary>
        /// Reads a list 
        /// </summary>
        public List<ushort> ReadListOfUInt16()
        {
            int length = ReadInt32();
            List<ushort> result = new List<ushort>();
            for (int i = 0; i < length; ++i)
                result.Add(ReadUInt16());
            return result;
        }

        /// <summary>
        /// Reads a list 
        /// </summary>
        public List<int> ReadListOfInt32()
        {
            int length = ReadInt32();
            List<int> result = new List<int>();
            for (int i = 0; i < length; ++i)
                result.Add(ReadInt32());
            return result;
        }

        /// <summary>
        /// Reads a list 
        /// </summary>
        public List<uint> ReadListOfUInt32()
        {
            int length = ReadInt32();
            List<uint> result = new List<uint>();
            for (int i = 0; i < length; ++i)
                result.Add(ReadUInt32());
            return result;
        }

        /// <summary>
        /// Reads a list 
        /// </summary>
        public List<double> ReadListOfDouble()
        {
            int length = ReadInt32();
            List<double> result = new List<double>();
            for (int i = 0; i < length; ++i)
                result.Add(ReadDouble());
            return result;
        }

        /// <summary>
        /// Reads a list 
        /// </summary>
        public List<float> ReadListOfSingle()
        {
            int length = ReadInt32();
            List<float> result = new List<float>();
            for (int i = 0; i < length; ++i)
                result.Add(ReadSingle());
            return result;
        }

        /// <summary>
        /// Reads a list 
        /// </summary>
        public List<DateTime> ReadListOfDateTime()
        {
            int length = ReadInt32();
            List<DateTime> result = new List<DateTime>();
            for (int i = 0; i < length; ++i)
                result.Add(ReadDateTime());
            return result;
        }

        /// <summary>
        /// Reads a list 
        /// </summary>
        public List<string> ReadListOfString()
        {
            int length = ReadInt32();
            List<string> result = new List<string>();
            for (int i = 0; i < length; ++i)
                result.Add(ReadString());
            return result;
        }

        /// <summary>
        /// Reads a list of packets
        /// </summary>
        public List<TEntity> ReadListOfEntity<TEntity>()
            where TEntity : IEntity, new()
        {
            int length = ReadInt32();
            List<TEntity> result = new List<TEntity>();

            for (int i = 0; i < length; ++i)
            {
                TEntity packet = new TEntity();
                packet.Read(this);
                result.Add(packet);
            }
            return result;
        }

        /// <summary>
        /// Reads a list of dynamic members
        /// </summary>
        public List<object> ReadListOfDynamic()
        {
            int length = ReadInt32();
            List<object> result = new List<object>();
            for (int i = 0; i < length; ++i)
                result.Add(ReadDynamic());
            return result;
        }

        #endregion

        #region Trace

        public static void FormatBuffer(TextWriter output, Stream input, int length)
        {
            output.WriteLine("        0  1  2  3  4  5  6  7   8  9  A  B  C  D  E  F");
            output.WriteLine("       -- -- -- -- -- -- -- --  -- -- -- -- -- -- -- --");

            int byteIndex = 0;

            int whole = length >> 4;
            int rem = length & 0xF;

            for (int i = 0; i < whole; ++i, byteIndex += 16)
            {
                StringBuilder bytes = new StringBuilder(49);
                StringBuilder chars = new StringBuilder(16);

                for (int j = 0; j < 16; ++j)
                {
                    int c = input.ReadByte();

                    bytes.Append(c.ToString("X2"));

                    if (j != 7)
                    {
                        bytes.Append(' ');
                    }
                    else
                    {
                        bytes.Append("  ");
                    }

                    if (c >= 0x20 && c < 0x80)
                    {
                        chars.Append((char)c);
                    }
                    else
                    {
                        chars.Append('.');
                    }
                }

                output.Write(byteIndex.ToString("X4"));
                output.Write("   ");
                output.Write(bytes.ToString());
                output.Write("  ");
                output.WriteLine(chars.ToString());
            }

            if (rem != 0)
            {
                StringBuilder bytes = new StringBuilder(49);
                StringBuilder chars = new StringBuilder(rem);

                for (int j = 0; j < 16; ++j)
                {
                    if (j < rem)
                    {
                        int c = input.ReadByte();

                        bytes.Append(c.ToString("X2"));

                        if (j != 7)
                        {
                            bytes.Append(' ');
                        }
                        else
                        {
                            bytes.Append("  ");
                        }

                        if (c >= 0x20 && c < 0x80)
                        {
                            chars.Append((char)c);
                        }
                        else
                        {
                            chars.Append('.');
                        }
                    }
                    else
                    {
                        bytes.Append("   ");
                    }
                }

                output.Write(byteIndex.ToString("X4"));
                output.Write("   ");
                output.Write(bytes.ToString());
                output.Write("  ");
                output.WriteLine(chars.ToString());
            }
        }

        #endregion

        #region Compression
        public int Decompress()
        {
            lock (LZF.Instance)
            {
                byte[] pooledBuffer;
                int handle = Buffers.Acquire(out pooledBuffer);
                byte[] outBuffer = pooledBuffer;
                int decompressedSize = LZF.Instance.Decompress(Data, 0, Size, ref outBuffer);

                // Release the actual reader's buffer 
                Buffers.Release(BufferHandle);
                BufferHandle = -1;
                Data = outBuffer;
                Size = decompressedSize;
                Index = 0;

                // Release the buffer if a new one was created meanwhile
                if (outBuffer != pooledBuffer)
                    Buffers.Release(handle);
                else
                { // Replace BufferHandle by a new one
                    BufferHandle = handle;
                }

                return decompressedSize;
            }
        }
        #endregion

    }
}