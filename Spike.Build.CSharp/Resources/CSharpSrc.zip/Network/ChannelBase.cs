﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Threading;
using System.IO;
using System.Globalization;

namespace Spike.Network
{
    /// <summary>
    /// An abstract class that represents a communication channel with a remote end point.
    /// </summary>
    public abstract class ChannelBase 
    {
        #region Properties
        private IPacketEncoder fPacketEncoder;
        protected bool fDisconnected = true;
        protected EndPoint fEndPoint;
        protected Uri fServerUri;
        protected string fProtocol = "";

        /// <summary>
        /// Gets or sets remote server end point.
        /// </summary>
        public virtual EndPoint EndPoint
        {
            get { return fEndPoint; }
            set
            {
                fEndPoint = value;
                fServerUri = new Uri(fProtocol + "://" + fEndPoint.ToString());
            }
        }

        /// <summary>
        /// Gets or sets remote server end point by Uri.
        /// </summary>
        public virtual Uri ServerUri
        {
            get { return fServerUri; }
            set 
            {
                fEndPoint  = ParseEndPoint(value.Host, value.Port);
                fServerUri = value;
            }
        }

        /// <summary>
        /// Gets or sets the packet encoder for this channel.
        /// </summary>
        public virtual IPacketEncoder PacketEncoder
        {
            get { return fPacketEncoder; }
            set { fPacketEncoder = value; }
        }

        #endregion

        /// <summary>
        /// Constructs a new instance of <see cref="ChannelBase"/> class.
        /// </summary>
        /// <param name="protocol">The communication protocol for this channel.</param>
        public ChannelBase(string protocol)
        {
            fProtocol = protocol;
        }

        #region Public Methods
        /// <summary>
        /// Performs a connection to the remote server
        /// </summary>
        /// <param name="host">Hostname to connect to</param>
        /// <param name="port">Port to connect through</param>
        public virtual void Connect(string host, int port) 
        {
            fEndPoint = ParseEndPoint(host, port);
            fServerUri = new Uri(fProtocol + "://" + fEndPoint.ToString());
            Connect();
        }

        /// <summary>
        /// Performs a connection to the remote server
        /// </summary>
        /// <param name="serverUri">Server Uri to connect to, must contain host name and the port</param>
        public virtual void Connect(Uri serverUri)
        {
            fEndPoint = ParseEndPoint(serverUri.Host, serverUri.Port);
            fServerUri = serverUri;
            Connect();
        }

        /// <summary>
        /// Performs a connection to the remote server
        /// </summary>
        /// <param name="endPoint">Remote end point</param>
        public virtual void Connect(EndPoint endPoint)
        {
            fEndPoint = endPoint;
            fServerUri = new Uri(fProtocol + "://" + fEndPoint.ToString());
            Connect();
        }

        /// <summary>
        /// Performs a socket receive in a loop, will dispatch the events (all in the same thread)
        /// Note: this is blocking
        /// </summary>
        /// <param name="sleep">Time in ms between each receive, will put current thread to sleep</param>
        /// <param name="check">A flag to check whether it is needed to exit the receive loop or not</param>
        public void ReceiveLoop(int sleep, ref bool check)
        {
            while (check)
            {
                Receive();
                Thread.Sleep(sleep);
            }
        }
        #endregion

        #region Read/Write Header
        internal static void WriteLength(Stream stream, int value)
        {
            byte[] buffer = new byte[4];
            buffer[0] = (byte)(value >> 24);
            buffer[1] = (byte)(value >> 16);
            buffer[2] = (byte)(value >> 8);
            buffer[3] = (byte)value;
            stream.Write(buffer, 0, 4);
        }

        internal static void WriteKey(Stream stream, string value)
        {
            byte[] buffer = new byte[Packet.HeaderKeySize];
            for (int i = 0; i < Packet.HeaderKeySize * 2; i+=2)
                buffer[i / 2] = byte.Parse(value.Substring(i, 2), System.Globalization.NumberStyles.HexNumber);

            stream.Write(buffer, 0, Packet.HeaderKeySize);
        }

        internal static int ReadLength(Stream stream)
        {
            return stream.ReadByte() << 24
                 | (stream.ReadByte() << 16)
                 | (stream.ReadByte() << 8)
                 | (stream.ReadByte());
        }

        internal static string ReadKey(Stream stream)
        {
            char[] chars = new char[Packet.HeaderKeySize * 2];
            byte current;
            byte readByte;

            for (int y = 0, x = 0; y < Packet.HeaderKeySize; ++y, ++x)
            {
                readByte   = (byte)stream.ReadByte();
                current    = ((byte)(readByte >> 4));
                chars[x]   = (char)(current > 9 ? current + 0x37 : current + 0x30);
                current    = ((byte)(readByte & 0xF));
                chars[++x] = (char)(current > 9 ? current + 0x37 : current + 0x30);
            }

            return new string(chars);
        }
        #endregion

        #region Abstract Methods and Properties
        /// <summary>
        /// Connects to the server
        /// </summary>
        protected abstract void Connect();

        /// <summary>
        /// Disconnects from the server
        /// </summary>
        public abstract void Disconnect();

        /// <summary>
        /// Invokes an operation on the server
        /// </summary>
        /// <param name="operationKey">The identifier for the operation to invoke on the server</param>
        /// <param name="packet">The body packet, can be null depending on the protocol specification</param>
        public abstract void Send(string operationKey, IPacket packet);

        /// <summary>
        /// Gets a value that indicates whether the channel is connected
        /// to a remote host as of the last send/receive operation
        /// </summary>
        public abstract bool IsConnected { get; }

        /// <summary>
        /// Gets/Sets whether the send aggregation should be used
        /// One must explicitly call SendAllPending() to send data in aggregated mode
        /// </summary>
        public abstract bool UseCoalescing { get; set; }

        /// <summary>
        /// If the channel is in coalescing mode, this will send all pending packets to the server
        /// </summary>
        public abstract void SendAllPending();

        /// <summary>
        /// Performs a receive, will dispatch the events (all in the same thread)
        /// </summary>
        public abstract void Receive();

        /// <summary>
        /// Invokes OnReceive method
        /// </summary>
        internal abstract void OnReceive(ChannelReceiveEventArgs e);
        #endregion

        #region Public Events
        /// <summary>
        /// This event fires when a underlying communication layer is connected to the remote server
        /// </summary>
        public event EventHandler<ConnectionEventArgs> Connected;

        /// <summary>
        /// This event fires when a underlying communication layer is disconnected from the remote server
        /// </summary>
        public event EventHandler<ConnectionEventArgs> Disconnected;

        /// <summary>
        /// Triggers the Connected event.
        /// </summary>
        protected virtual void OnConnected()
        {
            // If already in that state, do nothing
            if (!fDisconnected)
                return;

            // Keep a flag saying that the socket is connected
            fDisconnected = false;

            // Check if we need to send an event
            if (Connected != null)
            {
                // this is required, since the application
                // logic may block in a tight loop, and
                // we don't want to block the IO threads
                
                Thread applicationWorker = new Thread(
                    new ThreadStart(delegate()
                    {
                        Connected(this, new ConnectionEventArgs());
                    }
                ));

                applicationWorker.Start();
            }
        }

        /// <summary>
        /// Triggers the Disconnected event.
        /// </summary>
        protected virtual void OnDisconnected()
        {
            // If already in that state, do nothing
            if (fDisconnected)
                return;

            // Keep a flag saying that the socket is disconnected
            fDisconnected = true;

            // Check if we need to send an event
            if (Disconnected != null)
            {
                Thread applicationWorker = new Thread(
                    new ThreadStart(delegate()
                    {
                        Disconnected(this, new ConnectionEventArgs());
                    }
                ));

                applicationWorker.Start();
            }
        }
        #endregion

        #region Private Methods

        private IPEndPoint ParseEndPoint(string host, int port)
        {
            IPAddress address;
            if (!IPAddress.TryParse(host, out address))
            {
                IPAddress[] addresses = Dns.GetHostAddresses(host);
                if (addresses.Length == 0)
                {
                    throw new ArgumentException(
                        "Unable to retrieve address from specified host name.",
                        "hostName"
                    );
                }
                address = addresses[0];
            }

            return new IPEndPoint(address, port);
        }
        #endregion

    }
}
