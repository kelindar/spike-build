﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Spike.Network
{
    public class Packet
    {
        /// <summary>
        /// Total size of the header for each packet
        /// </summary>
        internal const int HeaderSize = HeaderLengthSize + HeaderKeySize;

        /// <summary>
        /// Size of the header bytes that determine Lenght of the packet
        /// </summary>
        internal const int HeaderLengthSize = 4;

        /// <summary>
        /// Size of the header data to add to the message length
        /// </summary>
        internal const int HeaderKeySize = 4;


        private string fOperation = "00000000";

        /// <summary>
        /// Gets or sets the operation identifier.
        /// </summary>
        public string Operation
        {
            get { return fOperation; }
            set { fOperation = value; }
        }

        /// <summary>
        /// Constructs a new instance of <see cref="Packet"/> class for the provided operation.
        /// </summary>
        /// <param name="operationKey">The operation identifier to bind the packet to.</param>
        public Packet(string operationKey)
        {
            fOperation = operationKey;
        }

    }
}
