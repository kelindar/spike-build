using System;
using System.Collections;
using System.Collections.Generic;

namespace Spike.Network
{

    #region BasePool Class
    internal abstract class BasePool<T> : IEnumerable<T>, IDisposable
    {

        /// <summary>
        /// Number of elements in the array (including dirty ones)
        /// </summary>
        public int RawCount;

        /// <summary>
        /// Number of used elements in the array
        /// </summary>
        public int Count;

        /// <summary>
        /// Underlying items array
        /// </summary>
        public T[] Items;

        protected int FreeListCount;
        protected int[] FreeList;
        protected byte[] UsedList;

        public BasePool()
        {
            this.Items = new T[4];
            this.FreeList = new int[4];
            this.UsedList = new byte[4];
        }

        public BasePool(int initialCapacity)
        {
            this.Items = new T[initialCapacity];
            this.FreeList = new int[initialCapacity];
            this.UsedList = new byte[initialCapacity];
        }


        /// <summary>
        /// Finds a new, not allocated spot
        /// </summary>
        protected int GetFreeIndex()
        {
            int handle = this.RawCount;
            if (handle < this.Items.Length)
            {
                if (Equals(this.Items[handle], default(T)))
                    return handle;
                else
                {
                    int len = this.Items.Length;
                    for (int i = handle; i < len; ++i)
                    {
                        if (Equals(this.Items[handle], default(T)))
                            return handle;
                    }
                }
            }

            // have to reallocate
            int newSize = this.RawCount;
            newSize |= newSize >> 1;
            newSize |= newSize >> 2;
            newSize |= newSize >> 4;
            newSize |= newSize >> 8;
            newSize |= newSize >> 16;
            newSize++;

            Array.Resize(ref this.Items, newSize);
            Array.Resize(ref this.UsedList, newSize);

            return handle;

        }

        /// <summary>
        /// Sets an item to a particular position in the array and marks as used
        /// </summary>
        public virtual void SetItem(int handle, T item)
        {
            this.Items[handle] = item;
            this.SetAsUsed(handle);
        }

        /// <summary>
        /// Set an item as used at a particular handle (in the case the search algorithm is handled differently)
        /// </summary>
        /// <param name="item">Acquired item</param>
        /// <param name="handle">handle to acquire at</param>
        protected void SetAsUsed(int handle)
        {
            if (this.UsedList[handle] == 0)
            {
                this.UsedList[handle] = 1;

                if (handle >= this.RawCount)
                {
                    // have to reallocate
                    int newSize = this.RawCount;
                    newSize |= newSize >> 1;
                    newSize |= newSize >> 2;
                    newSize |= newSize >> 4;
                    newSize |= newSize >> 8;
                    newSize |= newSize >> 16;
                    newSize++;

                    Array.Resize(ref this.Items, newSize);
                    Array.Resize(ref this.UsedList, newSize);
                }
                else
                {
                    if (this.FreeListCount == 1 && this.FreeList[0] == handle)
                    {
                        FreeListCount = 0;
                    }
                    else if (FreeListCount > 1)
                    {
                        // Remove from the free list
                        RemoveArrayItem<int>(ref this.FreeList, handle);
                        this.FreeListCount--;
                    }
                }
            }
        }

        private static int RemoveArrayItem<K>(ref K[] array, K removedItem)
        {
            int count = array.Length;

            if (count == 0)
                return -1;

            for (int i = 0; i < count; ++i)
            {
                if (!Equals(array[i], removedItem))
                    continue;

                K[] newArray = new K[count - 1];
                Array.Copy(array, 0, newArray, 0, i);
                Array.Copy(array, i + 1, newArray, i, count - i - 1);
                array = newArray;

                return i;
            }

            return -1;
        }

        /// <summary>
        /// Checks whether there is an element in use at a given position
        /// </summary>
        /// <param name="handle">The handle to check</param>
        /// <returns>True if there is an element in this position, otherwise false</returns>
        public bool HasElementAt(int handle)
        {
            return this.UsedList[handle] == 1;
        }


        #region IDisposable Members

        /// <summary>
        /// Frees the pool, deallocates the reserved memory
        /// </summary>
        public void FreeAll()
        {
            int count = this.RawCount;
            for (int i = 0; i < count; ++i)
                this.Items[i] = default(T); // set to default

            this.RawCount = 0;
            this.FreeListCount = 0;
        }

        /// <summary>
        /// Disposes the object
        /// </summary>
        public void Dispose()
        {
            FreeAll();
        }

        #endregion

        #region IEnumerable<T> Members

        public IEnumerator<T> GetEnumerator()
        {
            return new PoolCursor(this, 0, PoolCursorBehavior.Stop);
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return new PoolCursor(this, 0, PoolCursorBehavior.Stop);
        }

        #endregion

        #region Nested Iterator

        public enum PoolCursorBehavior
        {
            /// <summary>
            /// The cursor will stop when it has reached the end (beginning)
            /// </summary>
            Stop,
            /// <summary>
            /// The cursor will loop when it has reached the end (beginning)
            /// </summary>
            Loop
        }

        public struct PoolCursor : IEnumerator<T>
        {
            /// <summary>
            /// Underlying items array
            /// </summary>
            public BasePool<T> PoolRef;

            /// <summary>
            /// Currently selected handle
            /// </summary>
            public int SelectedHandle;

            /// <summary>
            /// Behavior for this cursor
            /// </summary>
            public PoolCursorBehavior Behavior;

            #region Constructors
            public PoolCursor(BasePool<T> poolRef)
            {
                this.PoolRef = poolRef;
                this.SelectedHandle = 0;
                Behavior = PoolCursorBehavior.Stop;
            }

            public PoolCursor(BasePool<T> poolRef, PoolCursorBehavior behavior)
            {
                this.PoolRef = poolRef;
                this.SelectedHandle = 0;
                Behavior = behavior;
            }

            public PoolCursor(BasePool<T> poolRef, int startingPosition)
            {
                this.PoolRef = poolRef;
                this.SelectedHandle = startingPosition;
                Behavior = PoolCursorBehavior.Stop;
            }

            public PoolCursor(BasePool<T> poolRef, int startingPosition, PoolCursorBehavior behavior)
            {
                this.PoolRef = poolRef;
                this.SelectedHandle = startingPosition;
                Behavior = behavior;
            }
            #endregion

            #region IEnumerator<T> Members

            public T Current
            {
                get
                {
                    if (this.PoolRef.Count == 0) // No elements, return default
                        return default(T);
                    return this.PoolRef.Items[this.SelectedHandle];
                }
            }


            object System.Collections.IEnumerator.Current
            {
                get
                {
                    if (this.PoolRef.Count == 0) // No elements, return default
                        return default(T);
                    return this.PoolRef.Items[this.SelectedHandle];
                }
            }

            public bool MoveNext()
            {
                int elems = this.PoolRef.Count;
                if (elems == 0) // No elements, can not move
                    return false;

                int count = PoolRef.RawCount;
                T[] items = PoolRef.Items;
                if (elems == 1 && this.PoolRef.HasElementAt(this.SelectedHandle)) // One element and it's already selected
                    return false;

                if (elems == 1) // One element, but the selected is dirty
                {
                    for (int i = 0; i < count; ++i)
                    {
                        if (!PoolRef.HasElementAt(i))
                            continue;
                        this.SelectedHandle = i;
                        return true; // we found the element
                    }
                    return false;
                }

                // Standard move next
                for (int i = this.SelectedHandle + 1; i < count; ++i)
                {
                    if (!PoolRef.HasElementAt(i))
                        continue;
                    this.SelectedHandle = i;
                    return true;
                }

                if (this.Behavior == PoolCursorBehavior.Stop)
                    return false;
                else // Loop from the beginning
                {
                    for (int i = 0; i < this.SelectedHandle; ++i)
                    {
                        if (!PoolRef.HasElementAt(i))
                            continue;
                        this.SelectedHandle = i;
                        return true;
                    }
                    return false;
                }
            }

            public void Reset()
            {
                int elems = this.PoolRef.Count;
                if (elems == 0)
                {
                    // No elements in the array, can't reset
                    SelectedHandle = 0;
                }
                else
                {
                    // Find first element
                    int count = this.PoolRef.RawCount;
                    T[] items = this.PoolRef.Items;
                    for (int i = 0; i < count; ++i)
                    {
                        if (!PoolRef.HasElementAt(i))
                            continue;
                        SelectedHandle = i;
                        return;
                    }
                }
            }

            public void Dispose()
            {
                // why there's always a dispose for an interator? crappy thing
            }

            #endregion

        }
        #endregion
    }
    #endregion

    internal class BufferPool : BasePool<byte[]>
    {
        private int fBufferSize;
        public BufferPool(int initialCapacity, int bufferSize)
            : base(initialCapacity)
        {
            fBufferSize = bufferSize;
            for (int i = 0; i < initialCapacity; ++i)
            {
                this.Items[i] = new byte[bufferSize];
                this.FreeList[i] = i;
                this.UsedList[i] = 0;
            }

            this.RawCount = initialCapacity;
            this.FreeListCount = initialCapacity;
            this.Count = 0;
        }

        /// <summary>
        /// Acquires an instance of byte[] and returns the reference to the instance
        /// as well as the handle in the Pool
        /// </summary>
        /// <param name="item">Reference to the recently acquired instance of byte[]</param>
        /// <returns>The handle in the Pool (index in the internal array)</returns>
        public int Acquire(out byte[] item)
        {
            lock (this.Items)
            {
                if (this.FreeListCount > 0)
                {
                    this.FreeListCount--;
                    int handle = this.FreeList[this.FreeListCount];
                    this.UsedList[handle] = 1;
                    this.Count++;

                    if (this.Items[handle] == null)
                    {
                        item = new byte[this.fBufferSize];
                        this.Items[handle] = item;
                        return handle;
                    }

                    item = this.Items[handle];
                    return handle;
                }
                else
                {
                    int handle = this.RawCount;
                    if (handle < this.Items.Length)
                    {
                        this.UsedList[handle] = 1;
                        this.Count++;

                        if (this.Items[handle] == null)
                        {
                            item = new byte[this.fBufferSize];
                            this.Items[handle] = item;
                            this.RawCount++;
                            return handle;
                        }

                        item = this.Items[handle];
                        this.RawCount++;
                        return handle;
                    }
                    else
                    {
                        // have to reallocate
                        int newSize = this.RawCount;
                        newSize |= newSize >> 1;
                        newSize |= newSize >> 2;
                        newSize |= newSize >> 4;
                        newSize |= newSize >> 8;
                        newSize |= newSize >> 16;
                        newSize++;

                        Array.Resize(ref this.Items, newSize);
                        Array.Resize(ref this.UsedList, newSize);

                        item = new byte[this.fBufferSize];
                        this.Items[handle] = item;
                        this.UsedList[handle] = 1;
                        this.Count++;
                        this.RawCount++;
                        return handle;
                    }
                }
            }
        }

        /// <summary>
        /// Acquires an instance of byte[] and returns the reference to the instance
        /// as well as the handle in the Pool
        /// </summary>
        /// <param name="item">Reference to the recently acquired instance of byte[]</param>
        /// <returns>The handle in the Pool (index in the internal array)</returns>
        public int Acquire(out byte[] buffer, int minimumLength)
        {
            lock (this.Items)
            {
                buffer = null;
                int handle = 0;

                if (this.FreeListCount > 0) // Check the free list
                {
                    // goes through freed items
                    for (int i = 0; i < this.FreeListCount; ++i)
                    {
                        // satisfies the length condition?
                        handle = this.FreeList[i];
                        if (this.Items[handle].Length >= minimumLength)
                        {
                            // Overwrite the current number with the last one
                            this.FreeList[i] = this.FreeList[--this.FreeListCount];
                            this.UsedList[handle] = 1;
                            this.Count++;

                            // Return the buffer
                            buffer = this.Items[handle];
                            return handle;
                        }
                    }
                }

                // Not found in free buffers, allocate
                handle = this.RawCount;
                if (handle < this.Items.Length)
                {
                    // Return a new buffer
                    buffer = AllocateBuffer(handle, minimumLength);
                    return handle;
                }
                else
                {
                    // have to reallocate
                    int newSize = this.RawCount;
                    newSize |= newSize >> 1;
                    newSize |= newSize >> 2;
                    newSize |= newSize >> 4;
                    newSize |= newSize >> 8;
                    newSize |= newSize >> 16;
                    newSize++;

                    Array.Resize(ref this.Items, newSize);
                    Array.Resize(ref this.UsedList, newSize);

                    // Return a new buffer
                    buffer = AllocateBuffer(handle, minimumLength);
                    return handle;
                }
            }
        }

        private byte[] AllocateBuffer(int handle, int minimumLength)
        {
            // Compute the size of the new buffer
            int newBufferSize = minimumLength;
            newBufferSize |= newBufferSize >> 1;
            newBufferSize |= newBufferSize >> 2;
            newBufferSize |= newBufferSize >> 4;
            newBufferSize |= newBufferSize >> 8;
            newBufferSize |= newBufferSize >> 16;
            newBufferSize++;

            // Allocate the buffer
            byte[] buffer = new byte[newBufferSize];
            this.Items[handle] = buffer;

            // Set the used list index & increment counters 
            this.UsedList[handle] = 1;
            this.RawCount++;
            this.Count++;

            return buffer;
        }

        /// <summary>
        /// Releases the instance of T specified by the handle
        /// </summary>
        /// <param name="handle"></param>
        public void Release(int handle)
        {
            lock (this.Items)
            {
                if (this.UsedList[handle] == 0)
                    return; // the spot is already free

                this.UsedList[handle] = 0;
                this.Count--;

                if (this.FreeListCount < this.FreeList.Length)
                {
                    this.FreeList[this.FreeListCount++] = handle;
                    return;
                }

                // have to reallocate
                int newSize = this.FreeListCount;
                newSize |= newSize >> 1;
                newSize |= newSize >> 2;
                newSize |= newSize >> 4;
                newSize |= newSize >> 8;
                newSize |= newSize >> 16;
                newSize++;

                Array.Resize(ref this.FreeList, newSize);
                this.FreeList[this.FreeListCount] = handle;
                this.FreeListCount++;
            }
        }

        /// <summary>
        /// Gets the buffer by its handle
        /// </summary>
        /// <param name="handle">The handle to get</param>
        /// <returns>Returns the buffer if one can be used, otherwize null</returns>
        public byte[] GetBuffer(int handle)
        {
            if (this.UsedList[handle] == 0)
                return null; // the spot is free
            return this.Items[handle];
        }

        /// <summary>
        /// Clears the pool without deallocating
        /// </summary>
        public void Clear()
        {
            int count = this.RawCount;
            for (int i = 0; i < count; ++i)
            {
                if (this.UsedList[i] == 1)
                    Release(i);
            }
        }
    }
}