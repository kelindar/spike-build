using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace Spike.Network
{
	/// <summary>
	/// Provides functionality for writing primitive binary data.
	/// </summary>
	public class PacketWriter
	{
        private static BufferPool Buffers = new BufferPool(2, 4 * 1024 * 1024);

        /// <summary>
        /// Instantiates a new PacketWriter instance with a given capacity.
        /// </summary>
        public PacketWriter()
        {
            fStream = new MemoryStream();
        }

        #region Properties

        /// <summary>
		/// Internal stream which holds the entire packet.
		/// </summary>
		private MemoryStream fStream;

		/// <summary>
		/// Internal format buffer.
		/// </summary>
		private byte[] m_Buffer = new byte[32];

        /// <summary>
        /// Gets the total stream length.
        /// </summary>
        public long Length
        {
            get { return fStream.Length; }
        }

        /// <summary>
        /// Gets or sets the current stream position.
        /// </summary>
        public long Position
        {
            get { return fStream.Position; }
            set { fStream.Position = value; }
        }

        /// <summary>
        /// The internal stream used by this PacketWriter instance.
        /// </summary>
        public MemoryStream UnderlyingStream
        {
            get { return fStream; }
            set { fStream = value; }
        }

        /// <summary>
        /// Offsets the current position from an origin.
        /// </summary>
        public long Seek(long offset, SeekOrigin origin)
        {
            return fStream.Seek(offset, origin);
        }

        /// <summary>
        /// Gets the entire stream content as a byte array.
        /// </summary>
        public byte[] ToArray()
        {
            return fStream.ToArray();
        }

        #endregion

        #region Write Primitives
        /// <summary>
		/// Writes a 1-byte boolean value to the underlying stream. False is represented by 0, true by 1.
		/// </summary>
		public void Write( bool value )
		{
			fStream.WriteByte( (byte)(value ? 1 : 0) );
		}

		/// <summary>
		/// Writes a 1-byte unsigned integer value to the underlying stream.
		/// </summary>
		public void Write( byte value )
		{
			fStream.WriteByte( value );
		}

		/// <summary>
		/// Writes a 1-byte signed integer value to the underlying stream.
		/// </summary>
		public void Write( sbyte value )
		{
			fStream.WriteByte( (byte) value );
		}

		/// <summary>
		/// Writes a 2-byte signed integer value to the underlying stream.
		/// </summary>
		public void Write( short value )
		{
			m_Buffer[0] = (byte)(value >> 8);
			m_Buffer[1] = (byte) value;

			fStream.Write( m_Buffer, 0, 2 );
		}

		/// <summary>
		/// Writes a 2-byte unsigned integer value to the underlying stream.
		/// </summary>
		public void Write( ushort value )
		{
			m_Buffer[0] = (byte)(value >> 8);
			m_Buffer[1] = (byte) value;

			fStream.Write( m_Buffer, 0, 2 );
		}

		/// <summary>
		/// Writes a 4-byte signed integer value to the underlying stream.
		/// </summary>
		public void Write( int value )
		{
			m_Buffer[0] = (byte)(value >> 24);
			m_Buffer[1] = (byte)(value >> 16);
			m_Buffer[2] = (byte)(value >>  8);
			m_Buffer[3] = (byte) value;

			fStream.Write( m_Buffer, 0, 4 );
		}

		/// <summary>
		/// Writes a 4-byte unsigned integer value to the underlying stream.
		/// </summary>
		public void Write( uint value )
		{
			m_Buffer[0] = (byte)(value >> 24);
			m_Buffer[1] = (byte)(value >> 16);
			m_Buffer[2] = (byte)(value >>  8);
			m_Buffer[3] = (byte) value;

			fStream.Write( m_Buffer, 0, 4 );
		}

        /// <summary>
        /// Writes a 8-byte signed integer value to the underlying stream.
        /// </summary>
        public void Write(long value)
        {
            m_Buffer[0] = (byte)(value >> 56);
            m_Buffer[1] = (byte)(value >> 48);
            m_Buffer[2] = (byte)(value >> 40);
            m_Buffer[3] = (byte)(value >> 32);
            m_Buffer[4] = (byte)(value >> 24);
            m_Buffer[5] = (byte)(value >> 16);
            m_Buffer[6] = (byte)(value >> 8);
            m_Buffer[7] = (byte)value;

            fStream.Write(m_Buffer, 0, 8);
        }

        /// <summary>
        /// Writes a 8-byte unsigned integer value to the underlying stream.
        /// </summary>
        public void Write(ulong value)
        {
            m_Buffer[0] = (byte)(value >> 56);
            m_Buffer[1] = (byte)(value >> 48);
            m_Buffer[2] = (byte)(value >> 40);
            m_Buffer[3] = (byte)(value >> 32);
            m_Buffer[4] = (byte)(value >> 24);
            m_Buffer[5] = (byte)(value >> 16);
            m_Buffer[6] = (byte)(value >> 8);
            m_Buffer[7] = (byte)value;

            fStream.Write(m_Buffer, 0, 8);
        }

        /// <summary>
        /// Writes a DateTime to a sequence of bytes to the underlying stream
        /// </summary>
        public void Write(DateTime value)
        {
            Write((short)value.Year);
            Write((short)value.Month);
            Write((short)value.Day);
            Write((short)value.Hour);
            Write((short)value.Minute);
            Write((short)value.Second);
            Write((short)value.Millisecond);
        }

        /// <summary>
        /// Writes an IEEE 754 double-precision (64-bit) floating-point number to the buffer
        /// </summary>
        public void Write(double value)
        {
            Write(BitConverter.DoubleToInt64Bits(value));
        }

        /// <summary>
        /// Writes an IEEE 754 single-precision (32-bit) floating-point number to the buffer
        /// </summary>
        public void Write(float value)
        {
            Write(BitConverter.GetBytes(value), 0, 4);
        }


		/// <summary>
		/// Writes a sequence of bytes to the underlying stream
		/// </summary>
		public void Write( byte[] buffer, int offset, int size )
		{
			fStream.Write( buffer, offset, size );
		}


		/// <summary>
		/// Writes a fixed-length big-endian unicode string value to the underlying stream. To fit (size), the string content is either truncated or padded with null characters.
		/// </summary>
		public void Write( string value )
		{
            if (String.IsNullOrEmpty(value))
            {
                Write((int)0);
            }
            else
            {
                byte[] stringBuffer = Encoding.UTF8.GetBytes(value);
                int size = stringBuffer.Length;

                Write(size);
                if (size > 0)
                {
                    fStream.SetLength(fStream.Length + size);
                    Write(stringBuffer, 0, size);
                }
            }
		}

        /// <summary>
        /// Writes a IPartialEntity in the packet
        /// </summary>
        public void Write(IEntity item)
        {
            item.Write(this);
        }

        /// <summary>
        /// Writes a byte array
        /// </summary>
        public void Write(byte[] array)
        {
            Write((int)array.Length);
            fStream.Write(array, 0, array.Length);
        }

        /// <summary>
        /// Writes a dynamic value (of the supported types)
        /// </summary>
        public void WriteDynamic(Object value)
        {
            Type type = value.GetType();
            string typeName = type.Name.ToString();
            switch (SupportedTypes.Map[type])
            {
                case 0:
                    Write((byte)1);
                    Write(typeName);
                    Write((byte)value);
                    break;
                case 1:
                    Write((byte)1);
                    Write(typeName);
                    Write((Int16)value);
                    break;
                case 2:
                    Write((byte)1);
                    Write(typeName);
                    Write((Int32)value);
                    break;
                case 3:
                    Write((byte)1);
                    Write(typeName);
                    Write((Int64)value);
                    break;
                case 4:
                    Write((byte)1);
                    Write(typeName);
                    Write((UInt16)value);
                    break;
                case 5:
                    Write((byte)1);
                    Write(typeName);
                    Write((UInt32)value);
                    break;
                case 6:
                    Write((byte)1);
                    Write(typeName);
                    Write((UInt64)value);
                    break;
                case 7:
                    Write((byte)1);
                    Write(typeName);
                    Write((Boolean)value);
                    break;
                case 8:
                    Write((byte)1);
                    Write(typeName);
                    Write((Single)value);
                    break;
                case 9:
                    Write((byte)1);
                    Write(typeName);
                    Write((Double)value);
                    break;
                case 10:
                    Write((byte)1);
                    Write(typeName);
                    Write((DateTime)value);
                    break;
                case 11:
                    Write((byte)1);
                    Write(typeName);
                    Write((String)value);
                    break;
                default:
                    // Not supported
                    Write((byte)0);
                    return;
            }
        }

        #endregion

        #region Write ILists
        /// <summary>
        /// Writes a list 
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write(IList<Boolean> list)
        {
            Write((int)list.Count);
            foreach (bool item in list) Write(item);
        }

        /// <summary>
        /// Writes a list 
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write(IList<Double> list)
        {
            Write((int)list.Count);
            foreach (double item in list) Write(item);
        }

        /// <summary>
        /// Writes a list 
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write(IList<Single> list)
        {
            Write((int)list.Count);
            foreach (float item in list) Write(item);
        }

        /// <summary>
        /// Writes a list 
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write(IList<byte> list)
        {
            Write((int)list.Count);
            foreach (byte item in list) Write(item);
        }


        /// <summary>
        /// Writes a list 
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write(IList<sbyte> list)
        {
            Write((int)list.Count);
            foreach (sbyte item in list) Write(item);
        }


        /// <summary>
        /// Writes a list 
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write(IList<short> list)
        {
            Write((int)list.Count);
            foreach (short item in list) Write(item);
        }


        /// <summary>
        /// Writes a list 
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write(IList<ushort> list)
        {
            Write((int)list.Count);
            foreach (ushort item in list) Write(item);
        }

        /// <summary>
        /// Writes a list
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write(IList<int> list)
        {
            Write((int)list.Count);
            foreach (int item in list) Write(item);
        }

        /// <summary>
        /// Writes a list
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write(IList<uint> list)
        {
            Write((int)list.Count);
            foreach (uint item in list) Write(item);
        }

        /// <summary>
        /// Writes a list
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write(IList<DateTime> list)
        {
            Write((int)list.Count);
            foreach (DateTime item in list) Write(item);
        }

        /// <summary>
        /// Writes a list
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write(IList<string> list)
        {
            Write((int)list.Count);
            foreach (string item in list) Write(item);
        }

        /// <summary>
        /// Writes a list of packets
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write(IList<IEntity> list)
        {
            Write((int)list.Count);
            foreach (IEntity item in list) item.Write(this);
        }

        /// <summary>
        /// Writes a list of packets
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void Write<TEntity>(IList<TEntity> list)
            where TEntity : IEntity
        {
            Write((int)list.Count);
            foreach (IEntity item in list) item.Write(this);
        }

        /// <summary>
        /// Writes a list of dynamic members
        /// </summary>
        /// <typeparam name="TList">The type of the list to write, should derive from IList generic</typeparam>
        /// <param name="list">The list instance to write</param>
        public void WriteDynamic(IList<object> list)
        {
            if (list == null)
            {
                Write((int)0);
                return;
            }
            Write((int)list.Count);
            for (int i = 0; i < list.Count; ++i)
                WriteDynamic(list[i]);
        }
        #endregion

        #region Compression
        public int Compress()
        {
            lock (LZF.Instance)
            {
                MemoryStream compressed = new MemoryStream();
                int length =  LZF.Instance.Compress(fStream.GetBuffer(), 0, (int)fStream.Length, compressed);
                fStream.Dispose();
                fStream = compressed;
                return length;
            }

        }
        #endregion
	}
}