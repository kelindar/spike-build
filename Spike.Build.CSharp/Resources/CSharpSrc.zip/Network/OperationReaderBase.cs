﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;

namespace Spike.Network
{
    internal abstract class OperationReaderBase 
    {
        internal static OperationReaderBase Instance;

        internal static void SetInstance(OperationReaderBase instance)
        {
            Instance = instance;
        }

        /// <summary>
        /// Reads an operation and returns the object it read
        /// </summary>
        internal abstract object Read(string operationKey, PacketReader reader);


    }

}
