﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Spike.Network
{
    public interface IPacket : IEntity
    {

    }

    /// <summary>
    /// Defines a contract for encoding/decoding packets.
    /// </summary>
    public interface IPacketEncoder
    {
        /// <summary>
        /// Defines how the outgoing packet is encoded. This may modify packet.CompiledBuffer property in order
        /// to recompile the packet body.
        /// </summary>
        /// <param name="channel">The channel that sends the packet.</param>
        /// <param name="buffer">The data buffer to send.</param>
        /// <param name="length">The length of the data buffer to send.</param>
        void EncodeOutgoingPacket(ChannelBase channel, ref byte[] buffer, ref int length);

        /// <summary>
        /// Defines how the incoming packet is decoded.
        /// </summary>
        /// <param name="channel">The channel that received the packet.</param>
        /// <param name="buffer">The received data buffer.</param>
        /// <param name="length">The length of the received data buffer.</param>
        void DecodeIncomingPacket(ChannelBase channel, ref byte[] buffer, ref int length);
    }
}
