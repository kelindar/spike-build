using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Spike.Network
{
    public sealed class PacketReceiveEventArgs<T> : EventArgs
        where T : class, IPacket
    {
        public T Data;
        public PacketReceiveEventArgs(IPacket dataReceived) { Data = dataReceived as T; }
    }

    public class LatencyComputedEventArgs : EventArgs
    {
        public uint Latency = 0;
        public LatencyComputedEventArgs(uint Latency) { this.Latency = Latency; }
    }
}