using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Spike.Network
{
    /// <summary>
    /// Represents event arguments for an event that is issued when a channel receives a packet.
    /// </summary>
    internal sealed class ChannelReceiveEventArgs : EventArgs
    {
        /// <summary>
        /// Gets the packet received.
        /// </summary>
        internal object Packet;

        /// <summary>
        /// Gets the operation key for the received packet.
        /// </summary>
        internal string Operation;

        /// <summary>
        /// Gets or sets whether the packet was handled or not.
        /// </summary>
        internal bool Handled = false;

        /// <summary>
        /// Constructs a new instance of <see cref=">ChannelReceiveEventArgs"/> class.
        /// </summary>
        /// <param name="operation">The operation key for the packet.</param>
        /// <param name="packet">The packet value.</param>
        internal ChannelReceiveEventArgs(string operation, object packet) 
        { 
            this.Operation = operation; 
            this.Packet = packet; 
        }
    }

}