using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Spike.Network
{
    public sealed class ConnectionEventArgs : EventArgs
    {
        public ConnectionEventArgs() : base() { }
    }

}