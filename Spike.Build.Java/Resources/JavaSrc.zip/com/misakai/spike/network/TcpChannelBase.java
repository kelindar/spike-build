package com.misakai.spike.network;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.channels.ClosedByInterruptException;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;

public abstract class TcpChannelBase {	
	
	private Socket socket;
	protected SocketChannel socketChannel;
	protected ByteBuffer receiveBuffer;
	protected ByteBuffer sendBuffer;
	private Thread backgroundThread; 
	
	public final ArrayList<ConnectionHandler> onConnect = new ArrayList<ConnectionHandler>();

	public TcpChannelBase(){
		//ThreadFactory factory = Executors.defaultThreadFactory();
		//ExecutorService executor = Executors.newFixedThreadPool(numberOfThreads);
		
		backgroundThread = new Thread(new Runnable() {			
			@Override
			public void run() {
				try {
					while(true){
						receiveBuffer.clear();
						
						socketChannel.read(receiveBuffer);
						int packetSize = receiveBuffer.getInt(0);						 
						
						while(packetSize + 4 > receiveBuffer.position())
							socketChannel.read(receiveBuffer);
						
						onReceive(receiveBuffer.getInt(4)); //give the key
					}
				} catch (ClosedByInterruptException e) {
					//disconnect create an IO exception
				} catch (IOException e) {
					e.printStackTrace();
				} 			
			}
		});
	}
	
	public void connect(String host, int port) throws UnknownHostException, IOException{
		socketChannel = SocketChannel.open();
		socketChannel.connect(new InetSocketAddress(host, port));
		socket = socketChannel.socket();
		receiveBuffer = ByteBuffer.allocate(socket.getReceiveBufferSize());
		sendBuffer = ByteBuffer.allocate(socket.getSendBufferSize());
		
		//Raise ConnectionHandlers
		for (ConnectionHandler connectionHandler : onConnect)
			connectionHandler.onConnect();
		
		backgroundThread.start();
	}	
	
	public void disconnect(){
		try {
			if(backgroundThread.isAlive())
				backgroundThread.interrupt();
			
			if(socketChannel.isOpen())			
				socketChannel.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//Read packets
	
	protected void beginReadPacket(boolean compressed){
		if(compressed && receiveBuffer.position() > 8){
			byte[] compressedData = new byte[receiveBuffer.position() - 8];
			receiveBuffer.position(8);			
			receiveBuffer.get(compressedData);
			
			byte[] uncompressedData = new byte[4096];
			int size = CLZF.decompress(compressedData, compressedData.length, uncompressedData, uncompressedData.length);
			
			receiveBuffer.position(8);		
			receiveBuffer.put(uncompressedData, 0, size);
		}						
		
		receiveBuffer.flip();
		receiveBuffer.position(8); // set buffer position and the data beginning
	}
	
    protected abstract void onReceive(int key);
    /*
    Supported types 
    
	Byte
	UInt16
	UInt32
	UInt64
	Int16
	Int32
	Int64
	Boolean	
	Single
	Double
	DateTime	
	String	       
	*/
    protected byte packetReadSByte(){
		return receiveBuffer.get();
	}
    
    protected short packetReadInt16(){
		return receiveBuffer.getShort();
	}
    
    protected int packetReadInt32(){
		return receiveBuffer.getInt();
	}
	
    protected long packetReadInt64(){
		return receiveBuffer.getLong();
	}
    
    protected byte packetReadByte(){
		return receiveBuffer.get();
	}
    
    protected short packetReadUInt16(){
		return receiveBuffer.getShort();
	}
    
    protected int packetReadUInt32(){
		return receiveBuffer.getInt();
	}
	
    protected long packetReadUInt64(){
		return receiveBuffer.getLong();
	}
    
    protected boolean packetReadBoolean(){
		return receiveBuffer.get() != 0;
	}
    
    protected float packetReadSingle(){
		return receiveBuffer.getFloat();
	}
    
    protected double packetReadDouble(){
		return receiveBuffer.getDouble();
	}
    
    //make protocol better
    protected Date packetReadDateTime(){
    	short year = receiveBuffer.getShort();
    	short month = receiveBuffer.getShort();
    	short day = receiveBuffer.getShort();
    	short hour = receiveBuffer.getShort();
    	short minute = receiveBuffer.getShort();
    	short seconds = receiveBuffer.getShort();
    	short miliseconds = receiveBuffer.getShort();
    	
    	GregorianCalendar calendar = new GregorianCalendar();
    	calendar.set(year,month,day,hour,minute,seconds);
    	long totalMilisec = calendar.getTimeInMillis();
    	totalMilisec += miliseconds;
		
    	return new Date(totalMilisec);
	}
    
    protected byte[] packetReadListOfByte(){
    	int size = receiveBuffer.getInt();
    	if(size > 0){
    		byte[] bytes = new byte[size];
			receiveBuffer.get(bytes);
			return bytes;
    	}
    	return null;
    }

    protected int[] packetReadListOfInt32(){
    	int size = receiveBuffer.getInt();
    	if(size > 0){
    		int[] ints = new int[size];
    		for(int index = 0; index < size; index++){
    			ints[index] = receiveBuffer.getInt();
    		}    		
    		return ints;
    	}
    	return null;
    }
        
	protected String packetReadString(){
		int size = receiveBuffer.getInt();
		if(size > 0){
			try {
				byte[] bytes = new byte[size];
				receiveBuffer.get(bytes);
				return new String(bytes,"UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}
		return "";
	}
	
	//Write packets	
	protected void beginNewPacket(int key){
		sendBuffer.clear();
		sendBuffer.position(4); //Skip size
		sendBuffer.putInt(key);
	}
	
	protected void packetWrite(byte value){
		sendBuffer.put(value);
	}
	
	protected void packetWrite(short value){
		sendBuffer.putShort(value);
	}
	
	protected void packetWrite(int value){
		sendBuffer.putInt(value);
	}
	
	protected void packetWrite(long value){
		sendBuffer.putLong(value);
	}
	
	protected void packetWrite(float value){
		sendBuffer.putFloat(value);
	}
	
	protected void packetWrite(double value){
		sendBuffer.putDouble(value);
	}
	
	protected void packetWrite(byte[] value){
		sendBuffer.putInt(value.length);
		sendBuffer.put(value);
	}
	
	protected void packetWrite(String value){		
		try {
			packetWrite(value.getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
		
	protected void sendPacket(boolean compressed){
		try {			
			if(compressed && sendBuffer.position() > 8){		
				byte[] uncompressedData = new byte[sendBuffer.position() - 8];
				sendBuffer.position(8);			
				sendBuffer.get(uncompressedData);
				
				byte[] compressedData = new byte[4096];
				int size = CLZF.compress(uncompressedData, uncompressedData.length, compressedData, compressedData.length);
				
				sendBuffer.position(8);		
				sendBuffer.put(compressedData, 0, size);
			}
			
			sendBuffer.flip();	
			
			sendBuffer.putInt(0, sendBuffer.remaining() - 4); //Set the Size (Don't count the size himself)						
			while(sendBuffer.hasRemaining()) {				
					socketChannel.write(sendBuffer);				
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
