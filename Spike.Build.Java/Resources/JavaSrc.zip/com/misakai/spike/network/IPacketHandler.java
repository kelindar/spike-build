package com.misakai.spike.network;

@FunctionalInterface
public interface IPacketHandler<Packet> {
	void onReceive(Packet packet);
}
