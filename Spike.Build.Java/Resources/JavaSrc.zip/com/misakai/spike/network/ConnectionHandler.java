package com.misakai.spike.network;

@FunctionalInterface
public interface ConnectionHandler {
	public void onConnect();
}
